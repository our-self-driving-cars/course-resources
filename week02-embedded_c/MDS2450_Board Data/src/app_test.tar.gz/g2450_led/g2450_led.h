/**
 @project	
 		G2450_LED Device Driver Header 
 	
 		2014.01.17  by Lee Dong su
 
 @section intro
		 	
 @section Program 
 	 	
 @section MODIFYINFO 
 
 
*/

#ifndef __G2450_LED_H__
#define __G2450_LED_H__

#define DEV_LED_MAJOR	221
#define DEV_LED_NAME	"g2450_led"

#define DEV_LED_IOCTL_MAGIC	'l'

#define DEV_LED_ON		_IOW(DEV_LED_IOCTL_MAGIC, 0, int)
#define DEV_LED_OFF		_IOW(DEV_LED_IOCTL_MAGIC, 1, int)
#define DEV_LED_IOCTL_MAXNR	2

#endif //__G2450_LED_H__

