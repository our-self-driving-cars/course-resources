/*
*	G2450_LED.C - The s3c2450 LED Device Driver 
*/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/vmalloc.h>
#include <asm/delay.h>
#include <asm/uaccess.h>
#include <linux/io.h>
#include <linux/ioctl.h>
#include <linux/fs.h>
#include <asm/gpio.h>
#include <plat/devs.h>
#include <linux/platform_device.h>
#include <plat/gpio-cfg.h>
#include <plat/s3c2416.h> 
#include <mach/regs-gpio.h>

#include "g2450_led.h"

static long g2450_led_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	int nu;
	
	copy_from_user((void *)&nu, (const void *)arg, sizeof( int ));

	nu += 4;

	switch(cmd) {
		case DEV_LED_ON: 
			gpio_direction_output(S3C2410_GPG(nu), 0);
			break;

		case DEV_LED_OFF:
			gpio_direction_output(S3C2410_GPG(nu), 1);
			break;

		default:
			return 0;
	}
	return 0;
}

static int g2450_led_open(struct inode *inode, struct file *filp)
{

	gpio_request(S3C2410_GPG(4), "LED 0");
	gpio_request(S3C2410_GPG(5), "LED 1");
	gpio_request(S3C2410_GPG(6), "LED 2");
	gpio_request(S3C2410_GPG(7), "LED 3");

    return 0;
}

static int g2450_led_release(struct inode *inode, struct file *filp)
{
	gpio_free(S3C2410_GPG(4));
	gpio_free(S3C2410_GPG(5));
	gpio_free(S3C2410_GPG(6));
	gpio_free(S3C2410_GPG(7));

    return 0;
}

struct file_operations g2450_led_fops = { 
    .open			= g2450_led_open,
    .release  		= g2450_led_release,
	.unlocked_ioctl	= g2450_led_ioctl,
};


static int __init g2450_led_init(void)
{

	printk("Insert led module!\n");

	register_chrdev( DEV_LED_MAJOR, DEV_LED_NAME, &g2450_led_fops );

	return 0;
}

static void __exit g2450_led_exit(void)
{
	printk("Remove led module!\n");

	unregister_chrdev( DEV_LED_MAJOR, DEV_LED_NAME );
}

module_init(g2450_led_init);
module_exit(g2450_led_exit);
MODULE_LICENSE("GPL");
