/**
 @project	
 		TCP Server ( for TCMS using GSM )
 	
 		2011.09.06  by Lee Dong su
 
 @section intro
		Recieve only
		 	
 @section Program 
 		Main Page
 	 	
 @section MODIFYINFO 
 
 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>

#include "../g2450_led.h"



int   main (int argc, char **argv)
{
	int dev_fd;
	char dev_name[1024];
	int nu;


	if( argc < 3 )
	{
		printf("./tst-led 1 off\n");
		exit(0);
	}

	bzero( dev_name, sizeof( dev_name ));
	sprintf( dev_name, "/dev/%s", DEV_LED_NAME );
	mknod( dev_name, S_IFCHR|S_IRWXU|S_IRWXG, MKDEV( DEV_LED_MAJOR, 0 ));
	printf("Make Device file(%s)\n", dev_name );

	dev_fd = open( dev_name, O_RDWR );
	if( 0 >= dev_fd )
	{
		printf("Open fail!\n");
		exit(0);
	}

	nu = atoi(argv[1]);
	if(!strcmp("off", argv[2]))
	{
		ioctl( dev_fd, DEV_LED_OFF, &nu );
		printf("LED %d Off\n", nu);
	}
	else
	{
		ioctl( dev_fd, DEV_LED_ON, &nu );
		printf("LED %d On\n", nu);
	}

	close( dev_fd );
	
    return 0;
}
