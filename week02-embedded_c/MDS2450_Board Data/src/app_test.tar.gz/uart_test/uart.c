#include    <stdio.h>
#include    <stdlib.h>
#include    <time.h>
#include    <unistd.h>                                                           // sleep
#include    <string.h>                                                           // sleep
#include    <fcntl.h>                                                           // sleep
#include    <sys/shm.h>                                                           // sleep
#include <sys/poll.h>

#include	<termios.h>



#define DEV_UART_NAME "/dev/ttySAC1"

#define FSTX	0x7E
#define FETX	0x7F
#define FID		0xF3

#define DSP_CMD_REQST 0x02
/**
 */
void	print_packet( char *data, int size )
{
	int lp;

	printf("Print!! ( %d ) \n", size );

	for( lp=0 ; lp<size ; lp++ )
	{
		printf("%02x ", data[lp]);
		if( 0 == lp % 32 )	printf("\n");
	}
	printf("\n-------------------------\n");
}

/**
 */
char	make_crc	( char *data, int size )
{
	char crc = 0;
	int lp = 0;

	for( lp=0 ; lp<size ; lp++ )
	{
		crc += data[lp];
	}
	crc = ~crc + 1;

	return crc;
}

/**
  serial init
*/
void    ser_init    ( int fd, unsigned int baud , unsigned int vtime, unsigned int vmin )
{
	struct termios  newtio;


	// ½Ã¸®¾ó Æ÷Æ® È¯°æÀ» ¼³Á¤ÇÑ´Ù.
	memset(&newtio, 0, sizeof(newtio));
	newtio.c_iflag = IGNPAR;        // non-parity
	newtio.c_oflag = 0;

	newtio.c_cflag = CS8 | CLOCAL | CREAD;  // NO-rts/cts

	switch( baud )
	{
		case 115200 : newtio.c_cflag |= B115200; break;
		case 57600  : newtio.c_cflag |= B57600;  break;
		case 38400  : newtio.c_cflag |= B38400;  break;
		case 19200  : newtio.c_cflag |= B19200;  break;
		case 9600   : newtio.c_cflag |= B9600;   break;
		case 4800   : newtio.c_cflag |= B4800;   break;
		case 2400   : newtio.c_cflag |= B2400;   break;
		default     : newtio.c_cflag |= B115200; break;
	}

	//set input mode (non-canonical, no echo,.....)
	newtio.c_lflag = 0;

	newtio.c_cc[VTIME] = vtime;  // timeout 0.1ÃÊ ´ÜÀ§
	newtio.c_cc[VMIN]  = vmin;   // ÃÖ¼Ò n ¹®ÀÚ ¹ÞÀ» ¶§±îÁø ´ë±â

	tcflush  ( fd, TCIFLUSH );
	tcsetattr( fd, TCSANOW, &newtio );

}

