#include    <stdio.h>
#include    <stdlib.h>
#include    <time.h>
#include    <unistd.h>                           // sleep
#include	<poll.h>
#include	<string.h>
#include	<sys/shm.h>
#include    <fcntl.h>                                                           // sleep
#include	<termios.h>

#include	"uart.h"



/**
  	main function
*/
int   main( int argc, char *argv[] )
{
	int fd;
	char txbuf[1024];
	char rxbuf[1024];


	fd = open("/dev/ttySAC2", O_RDWR);

	ser_init( fd, 115200 , 0, 1 );


	printf("Run!!!\n");
	memset( txbuf, 0, sizeof( txbuf ));
	sprintf( txbuf, "TX Test\n");
	write(fd, txbuf, strlen( txbuf ));
	printf("Write!!!\n");

	while(1)
	{
		memset( rxbuf, 0, sizeof( rxbuf ));
		read( fd, rxbuf, sizeof( rxbuf ));
		printf("RX: %s\n", rxbuf );

		memset( txbuf, 0, sizeof( txbuf ));
		sprintf(txbuf, "MDS2450: %s\n\r", rxbuf );
		write(fd, txbuf, strlen( txbuf ));
		sleep(1);
	}

	return   0;
}
