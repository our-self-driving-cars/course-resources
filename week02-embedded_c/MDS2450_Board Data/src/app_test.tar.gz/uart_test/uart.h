/*
 *
 * UART interface header file
 * 
 * dsUtil UART header
 * 
 * 2013. 11. 30
 * Designed by Gemini(Lee Dong su)
 *
 */


#ifndef __DSUART_H__
#define __DSUART_H__

extern void    ser_init    ( int fd, unsigned int baud , unsigned int vtime, unsigned int vmin );



#endif // __DSUART_H__



