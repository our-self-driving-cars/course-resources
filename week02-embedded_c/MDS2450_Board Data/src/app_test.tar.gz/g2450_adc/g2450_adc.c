/*
*	G2450_ADC.C - The s3c2450 adc module.
*/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/vmalloc.h>
#include <asm/delay.h>
#include <linux/io.h>
#include <plat/adc.h>
#include <plat/devs.h>
#include <linux/platform_device.h>
#include <linux/kdev_t.h>
#include <asm/uaccess.h>
#include <linux/fs.h>


#define G2450_ADC_MAJOR 68
static char dev_adc_name[] = "g2450-adc";

static struct s3c_adc_client   *adc_client;
static int adc_minor = 0;

static struct platform_device g2450_adc_dev[]= {
	[0] = { 
		.name             = "s3c-adc",
		.id               = -1,
	},
};


static ssize_t g2450_adc_read(struct file *filp, char *buff, size_t count, loff_t *offp)
{
	int  val;

	val = s3c_adc_read(adc_client, adc_minor);

	copy_to_user((void *)buff, (const void *)&val, sizeof( int ));

	return 0;
}
static int g2450_adc_open(struct inode *inode, struct file *file)
{
	if( 1 < iminor(inode))
		return -1;

	adc_minor = iminor(inode);
	printk("ADC Device %d\n", adc_minor);

	return 0;
}

static void g2450_adc_release(struct inode *inode, struct file *file)
{
	return ;
}

static struct file_operations g2450_adc_fops = {
	.owner 	= THIS_MODULE,
	.open 	= g2450_adc_open,
	.release= g2450_adc_release,
	.read 	= g2450_adc_read,
};



static int __init g2450_adc_init(void)
{
	// register adc
	adc_client = s3c_adc_register(g2450_adc_dev, NULL, NULL, 0);

	register_chrdev( G2450_ADC_MAJOR, dev_adc_name, &g2450_adc_fops );

	return 0;
}

static void __exit g2450_adc_exit(void)
{
	// unregister adc
	s3c_adc_release(adc_client);

	unregister_chrdev( G2450_ADC_MAJOR, dev_adc_name );
}

module_init(g2450_adc_init);
module_exit(g2450_adc_exit);
MODULE_LICENSE("GPL");
