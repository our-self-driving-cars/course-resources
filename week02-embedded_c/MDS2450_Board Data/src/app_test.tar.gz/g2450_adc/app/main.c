/**
 @project	
 		MDS2450 Key scan test program
 	
 		2014.02.06  by Gemini
 
 @section intro
		 	
 @section Program 
 		Main Page
 	 	
 @section MODIFYINFO 
 
 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>

#define G2450_ADC_MAJOR 68

int   main (int argc, char **argv)
{
    int dev_fd;
    char dev_path[32];
	int val;
	int minor = 0;
    

	if( 1 < argc )
	{
		minor = atoi( argv[1] );
	}
	sprintf(dev_path, "/dev/g2450_adc_%d", minor);
   	mknod( dev_path, (S_IRWXU|S_IRWXG|S_IFCHR), MKDEV( G2450_ADC_MAJOR, minor )); 

    dev_fd = open(dev_path, O_RDWR );
    if( 0 > dev_fd )
	{
		printf("Open fail!! ADC %d\n", minor);
		return -1;
	}
	printf("Open ADC %d\n", minor );
    

	while(1)
	{    	
		read( dev_fd, &val, sizeof( int ));	
		printf("ADC %d: %d\n", minor, val );
		sleep(1);
	}

    close(dev_fd);
    
    return 0;
}

