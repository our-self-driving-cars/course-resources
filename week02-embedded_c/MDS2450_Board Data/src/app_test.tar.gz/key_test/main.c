/**
 @project	
 		MDS2450 Key scan test program
 	
 		2014.02.06  by Gemini
 
 @section intro
		 	
 @section Program 
 		Main Page
 	 	
 @section MODIFYINFO 
 
 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>

#define MDS2450_KSCAN_MAJOR 67

int   main (int argc, char **argv)
{
    int dev_fd;
    char dev_path[32];
	int key;
	int ret;
    
	sprintf(dev_path, "/dev/kscan");
   	mknod( dev_path, (S_IRWXU|S_IRWXG|S_IFCHR), MKDEV( MDS2450_KSCAN_MAJOR, 0 )); 

    dev_fd = open(dev_path, O_RDWR );
    if( 0 > dev_fd )	printf("Open fail!!\n");
    
	while(1)
	{    	
		ret = read( dev_fd, &key, sizeof( int ));	
		if( 0 < ret )	printf("Press Key %d\n", key);
		sleep(1);
	}

    close(dev_fd);
    
    return 0;
}

