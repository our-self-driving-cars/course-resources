/**
 @project	
 		TCP Server ( for TCMS using GSM )
 	
 		2011.09.06  by Lee Dong su
 
 @section intro
		Recieve only
		 	
 @section Program 
 		Main Page
 	 	
 @section MODIFYINFO 
 
 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/kdev_t.h>

#include "../g2450_pwm.h"



int   main (int argc, char **argv)
{
	int dev_fd;
	char dev_name[1024];
	struct g2450_pwm_duty_t pwm_duty;


	if( argc < 3 )
	{
		printf("./tst-pwm 150000 200000\n");
		exit(0);
	}

	bzero( dev_name, sizeof( dev_name ));
	sprintf( dev_name, "/dev/%s", DEV_PWM_NAME );
	mknod( dev_name, S_IFCHR|S_IRWXU|S_IRWXG, MKDEV( DEV_PWM_MAJOR, 0 ));
	printf("Make Device file(%s)\n", dev_name );

	dev_fd = open( dev_name, O_RDWR );
	if( 0 >= dev_fd )
	{
		printf("Open fail!\n");
		exit(0);
	}

	ioctl( dev_fd, DEV_PWM_STOP );
	
	pwm_duty.pulse_width = atoi( argv[1] );
	pwm_duty.period = atoi( argv[2] );
	ioctl( dev_fd, DEV_PWM_DUTYRATE, &pwm_duty );
	printf("Duty: %d, Period: %d\n", pwm_duty.pulse_width, pwm_duty.period );

	ioctl( dev_fd, DEV_PWM_RUN );
	printf("Run PWM!!\n");


	while(1);

	close( dev_fd );
    
    return 0;
}
