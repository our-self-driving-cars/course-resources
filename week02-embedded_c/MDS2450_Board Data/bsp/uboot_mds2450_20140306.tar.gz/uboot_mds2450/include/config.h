/* Automatically generated - do not edit */
#include <configs/mds2450.h>
