#cgitime.py
print("Content-Type : text/plain\n\n")
import time

print(time.ctime())

