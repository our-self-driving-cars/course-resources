print('\a')
