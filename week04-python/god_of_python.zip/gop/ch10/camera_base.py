# camera_base.py
def photo():
    print("Take a photo")
photo()
