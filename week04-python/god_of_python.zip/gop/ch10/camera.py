# camera.py
def photo():
    print("Take photo")

photo()
print("camera.py's module name is", __name__)  # 추가(모듈의 이름을 출력)
