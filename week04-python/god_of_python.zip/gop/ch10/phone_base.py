# phone_base.py
def makeacall():
    print("Make a Call")
makeacall()
