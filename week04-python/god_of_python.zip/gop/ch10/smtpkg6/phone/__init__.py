# C:\gop\ch10\smtpkg5\phone\_ _init_ _.py
from . import phone
