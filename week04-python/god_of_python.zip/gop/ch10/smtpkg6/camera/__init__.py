# C:\gop\ch10\smtpkg5\camera\_ _init_ _.py
from . import camera
