# phone_mod.py
def makeacall():
    print("Make a Call")
if __name__ == '__main__':
    makeacall()  # import 될 때는 실행되지 않는 코드
