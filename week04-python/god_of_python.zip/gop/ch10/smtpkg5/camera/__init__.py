# C:\gop\ch10\smtpkg5\camera\_ _init_ _.py
from smtpkg5.camera import camera
