# C:\gop\ch10\smtpkg5\_ _init_ _.py
from smtpkg5 import camera  # smtpkg5의 하위 패키지 camera를 등록
from smtpkg5 import phone  # smtpkg5의 하위 패키지 phone을 등록

__all__ = ['camera', 'phone']  # 추가
