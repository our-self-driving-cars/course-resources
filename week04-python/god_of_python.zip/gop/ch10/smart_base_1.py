# smart_base_1.py
import camera_base
import phone_base
print("-----")
camera_base.photo()  # 모듈에 정의된 함수에 접근하기 위해서는 (.)을 이용한다.
phone_base.makeacall()
phone_base.makeacall()
