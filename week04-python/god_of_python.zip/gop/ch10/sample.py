# sample.py
x = 77


def sample_func():
    print('x is', x)
