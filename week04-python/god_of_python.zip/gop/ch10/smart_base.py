#smart_base.py
import camera_base #camera_base.py를 불러들임
import phone_base