# argv_example.py
import sys
print(sys.argv)  # 명령행에 전달된 값들을 출력
