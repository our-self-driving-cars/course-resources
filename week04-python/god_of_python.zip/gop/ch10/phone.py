# phone.py
def makeacall():
    print("Make a Call")

makeacall()
print("phone.py's module name is", __name__)  # 추가(모듈의 이름을 출력)
