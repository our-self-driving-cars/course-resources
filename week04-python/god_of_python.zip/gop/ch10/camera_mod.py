# camera_mod.py
def photo():
    print("Take a photo")

if __name__ == '__main__':  # 직접 실행된 경우에만 True
    photo()  # import 될 때는 실행되지 않는 코드
