# main.py
import sample
x = 222


def main_func():
    print('x is', x)

sample.sample_func()
main_func()
