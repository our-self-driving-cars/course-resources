#B.py
var = 77
def b():
    print(var)
