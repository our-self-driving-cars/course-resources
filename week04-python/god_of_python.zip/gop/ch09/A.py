#A.py
import B
var = 100
def a():
    print(var)

B.b()
a()
