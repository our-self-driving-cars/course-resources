#camera.py
from ..subcam import	subcam

def photo():
    print("Take photo")

if __name__ == '__main__':
    photo()
