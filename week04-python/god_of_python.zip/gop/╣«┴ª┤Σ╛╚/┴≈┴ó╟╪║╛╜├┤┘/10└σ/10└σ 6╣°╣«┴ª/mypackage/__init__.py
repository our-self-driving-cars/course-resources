from mypackage import a
from mypackage import b