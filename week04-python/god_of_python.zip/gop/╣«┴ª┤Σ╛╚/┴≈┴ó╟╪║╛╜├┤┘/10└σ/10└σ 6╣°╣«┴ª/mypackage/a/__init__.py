from mypackage.a import a
