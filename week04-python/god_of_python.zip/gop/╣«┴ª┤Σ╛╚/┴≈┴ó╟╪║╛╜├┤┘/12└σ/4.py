class MyClass():
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def introduce(self):
        print("My name is {}. {} year's old".format(self.name, self.age))

if __name__ == "__main__":
    import pickle
    obj = MyClass("Chul su", 19)
    with open("pickle_test", 'wb') as f:
        pickle.dump(obj, f)             #저장
    
    with open("pickle_test", 'rb') as f:
        obj = pickle.load(f)            #로드
    obj.introduce()
