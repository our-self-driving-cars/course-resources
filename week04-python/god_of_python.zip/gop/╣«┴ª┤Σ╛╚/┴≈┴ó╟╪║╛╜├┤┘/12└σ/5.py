s = "python"
s_utf8 = s.encode("utf-8")
s_utf16 = s.encode("utf-16")


##utf-8 인코딩을 사용할 때##
with open("utf8.txt", "wb") as f:
    f.write(s_utf8)
#또는
""""
with open("utf8.txt", "wt", encoding="utf-8") as f:
    f.write("python")
"""

##utf-16인코딩을 사용할 때##
with open("utf16.txt", "wb") as f:
    f.write(s_utf16)
#또는
""""
with open("utf16.txt", "wt", encoding="utf-16") as f:
    f.write("python")
"""
