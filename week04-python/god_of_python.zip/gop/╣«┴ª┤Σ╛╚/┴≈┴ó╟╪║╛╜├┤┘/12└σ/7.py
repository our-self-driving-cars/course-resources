data = [236, 130, 172, 235, 158, 145]
b_data = bytes(data)
print(b_data.decode("utf-8"))