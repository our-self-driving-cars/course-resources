import sys

try:
    f = open(sys.argv[1], "rt")
except IndexError:
    print("usage : python 1.py object_file (ex : python 1.py 1.txt)")
else:
    total = 0
    for line in f.readlines():
        if line == "\n":
            continue
        total += len(line.strip().split(' '))
    print("{}에 쓰여진 단어 수".format(sys.argv[1]), total)
