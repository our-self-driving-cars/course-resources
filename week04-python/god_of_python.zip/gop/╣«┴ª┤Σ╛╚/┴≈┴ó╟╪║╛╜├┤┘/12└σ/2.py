import os
with open("fruit.txt", 'r+') as f:
    while True:
        f.seek(0,0)
        fruit_list = f.readlines()
        
        os.system('cls')
        print("**물품목록**")
        for l in fruit_list:
            print(l,end='')
        print('')

        data = input("입력 : ")
        fruit = data.split(' ')

        for i in range(0, len(fruit_list)):
            three = (fruit_list[i].strip()).split('|')
            if three:
                if three[0]==fruit[0] and three[1]==fruit[1]:
                    fruit_list[i] = three[0]+'|'+three[1]+'|'+str(int(three[2])+int(fruit[2]))+'\n'
                    f.seek(0,0)
                    f.writelines(fruit_list)
                    f.flush()
                    break
        else:
            print("해당 물품이 없습니다.")
