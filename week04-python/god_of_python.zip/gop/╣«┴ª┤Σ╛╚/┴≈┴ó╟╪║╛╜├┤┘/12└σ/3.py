import time
import os
def func_change():
    data = input("물품 수량 가격을 공백으로 구분하여 입력하시오 : ") 
    fruit = data.split(' ')
    for i in range(0, len(fruit_list)):
        three = (fruit_list[i].strip()).split('|')
        if three:
            if three[0]==fruit[0] and three[1]==fruit[1]:
                fruit_list[i] = three[0]+'|'+three[1]+'|'+str(int(three[2])+int(fruit[2]))+'\n'
                f.seek(0,0)
                f.writelines(fruit_list)
                f.flush()
                break
    else:
        print("해당 물품이 없습니다.")
        time.sleep(1)


def func_add():
    data = input("새롭게 등록할 물품명과 가격을 입력하시오. : ") 
    fruit = data.split(' ')
    try:
        isinstance(fruit[0], str)
        isinstance(int(fruit[1]), int)
        isinstance(int(fruit[2]), int)        
        if len(fruit) != 3:
            raise IndexError
    except (ValueError, IndexError):
        print("입력 형식이 정확하지 않습니다.")
        time.sleep(1)
        return 0

    for l in fruit_list:
        three = l.strip().split('|')
  
        if three:
            if three[0] == fruit[0] and three[1] == fruit[1]:
                print("동일한 물품이 있습니다")
                time.sleep(1)
                break
    else:

        fruit_list.append("|".join(data.split(' ')))
        f.seek(0,0)
        for line in fruit_list:
            f.write(line.strip() + "\n")
            f.flush()

with open("fruit.txt", 'r+') as f:
    while True:
        f.seek(0,0)
        fruit_list = f.readlines()
        
        os.system('cls')
        print("**전체 물품 목록**")
        for l in fruit_list:
            print(l,end='')
        print('')

        data = input("선택(a, b, c) : ")
        
        if data =='a':
            continue
        elif data =='b':
            func_change()
        elif data =='c':
            func_add()
