import tkinter
import sqlite3
from tkinter import messagebox


conn = sqlite3.connect("C:/sqlite/mydb.db")
c = conn.cursor()
curtable = "word_basic"
selection_content = None


class App():
    def __init__(self, master):
        self.master = master
        self.master.protocol("WM_DELETE_WINDOW", func=self.delete_window)
        self.master.title("python_word_Dic")
        self.master.geometry("657x390+800+800")

        self.framel = tkinter.Frame(master, width=130, height=380)
        self.framec = tkinter.Frame(master, width=130, height=380)
        self.framer = tkinter.Frame(master, width=130, height=380)
        self.framel.grid(row=0, column=0)
        self.framec.grid(row=0, column=1)
        self.framer.grid(row=0, column=2)

        self.word_string = tkinter.StringVar()
        self.word_string.set("_")
        self.word_label = tkinter.Label(self.framel, textvariable=self.word_string, background='green')
        self.word_label.grid(row=0, column=0, sticky='w')
        self.word_list = tkinter.Listbox(self.framel, height=20, background='yellow')
        self.word_list.grid(row=1, column=0)
        self.delete_word_button = tkinter.Button(self.framel, text="delete_word")
        self.delete_word_button.grid(row=2, column=0, sticky='E')


        self.meaning_text = tkinter.Text(self.framec, width=50, height=9)
        self.meaning_text.grid(row=0, column=0, columnspan=4, pady=20)
        
        self.word_input_label = tkinter.Label(self.framec, text="word")
        self.word_input_label.grid(row=1, column=0)
        self.word_input_entry = tkinter.Entry(self.framec, width=10)
        self.word_input_entry.grid(row=1, column=1, sticky="E")
        self.level_input_label = tkinter.Label(self.framec, text="Level")
        self.level_input_label.grid(row=1, column=2)
        self.level_input_entry = tkinter.Entry(self.framec, width=2)
        self.level_input_entry.grid(row=1, column=3)
        self.meaning_input_label = tkinter.Label(self.framec, text='meaning')
        self.meaning_input_label.grid(row=2, column=0)
        self.meaning_input_text = tkinter.Text(self.framec, width=38, height=7)
        self.meaning_input_text.grid(row=2, column=1, columnspan=3)

        self.input_data_button = tkinter.Button(self.framec, text='input')
        self.input_data_button.grid(row=3, column=3)
        
        self.table_label = tkinter.Label(self.framec, text='table name')
        self.table_label.grid(row=4, column=1)
        self.table_entry = tkinter.Entry(self.framec)
        self.table_entry.grid(row=4, column=2, pady=20)
        self.create_table_button = tkinter.Button(self.framec, text='Create!')
        self.create_table_button.grid(row=4, column=3)

        self.db_string = tkinter.StringVar()
        self.db_string.set(curtable)
        self.db_label = tkinter.Label(self.framer, textvariable=self.db_string, background='green')
        self.db_label.grid(row=0, column=0, sticky='w')
        self.db_list = tkinter.Listbox(self.framer, height=20, background='yellow')
        self.db_list.grid(row=1, column=0, sticky='n')
        self.delete_table_button = tkinter.Button(self.framer, text="delete_table")
        self.delete_table_button.grid(row=2, column=0, sticky='E')

    def delete_window(self):
        c.close()
        conn.commit()
        conn.close()
        self.master.destroy()


root = tkinter.Tk()
myApp = App(root)


def check_table():
    c.execute("""SELECT name FROM sqlite_master WHERE type='table'""")  # 해당 DB에서 모든 테이블을 검색
    table_list = c.fetchall()
    myApp.db_list.delete(0, "end")
    for i in range(0, len(table_list)):
        myApp.db_list.insert(i, table_list[i][0])


def check_word():
    myApp.word_list.delete(0, 'end')
    c.execute("""SELECT word from {}""".format(curtable))
    words = c.fetchall()
    for i in range(0, len(words)):
        myApp.word_list.insert(i, words[i][0])


def select_word(e):
    global selection_content
    try:
        selection_index = e.widget.curselection()[0]
    except IndexError:      # 테이블에 선택할 단어가 하나도 없을 때
        return 0
    selection_content = e.widget.get(selection_index)
    myApp.word_string.set(selection_content)
    c.execute("""SELECT meaning FROM {} WHERE word='{}'""".format(curtable, selection_content))
    mean = c.fetchall()
    myApp.meaning_text.delete("1.0", "end")
    myApp.meaning_text.insert("end", mean[0][0])


def select_table(e):
    global curtable
    try:
        selection_index = e.widget.curselection()[0]
    except IndexError:                 # DB에 선택할 테이블이 없을 때
        return 0
    selection_tablename = e.widget.get(selection_index)
    curtable = selection_tablename
    check_word()
    myApp.db_string.set(curtable)


def input_data():
    word = myApp.word_input_entry.get()
    meaning = myApp.meaning_input_text.get("1.0", "end-1c")
    level = myApp.level_input_entry.get()
    if len(word) and len(meaning):
        if level=='1' or level=='2' or level=='3':
            pass
        else:
            messagebox.showwarning(title="warning", detail="level의 값은 1, 2, 3 중에 하나의 값입니다.")
            return 0    
    else:
        messagebox.showwarning(title="warning", detail="모든 칸을 다 채워주세요.")
        return 0
    
    c.execute("""SELECT * FROM {} WHERE word='{}'""".format(curtable, word))
    find_list = c.fetchall()
    if find_list:
        messagebox.showwarning(title="warning", detail='한 테이블에 같은 단어를 두번 입력할 수 없습니다.')
        return 0
    else:
        #c.execute("INSERT INTO ? VALUES(?,?,?)", (curtable, word, meaning, level))
        c.execute("INSERT INTO {} VALUES('{}','{}','{}')".format(curtable, word, meaning, level))
        myApp.word_input_entry.delete(0, "end")
        myApp.meaning_input_text.delete('1.0', "end")
        myApp.level_input_entry.delete(0, "end")
        check_word()
    return 0


def delete_data():
    global selection_content
    c.execute("""DELETE  from {} WHERE word='{}'""".format(curtable, selection_content))
    check_word()


def delete_table():
    r = messagebox.askokcancel(title='삭제 경고', detail="테이블 {}을 삭제하시겠습니까?".format(curtable))
    if r:
        c.execute("DROP TABLE {}".format(curtable))
        check_table()
    else:
        pass
    return 0


def create_table():
    tblname = myApp.table_entry.get()
    c.execute("""CREATE TABLE {}(word, meaning, level)""".format(tblname))
    check_table()

myApp.word_list.bind("<<ListboxSelect>>", select_word)
myApp.db_list.bind("<<ListboxSelect>>", select_table)
myApp.input_data_button.configure(command=input_data)
myApp.delete_word_button.configure(command=delete_data)
myApp.delete_table_button.configure(command=delete_table)
myApp.create_table_button.configure(command=create_table)

try:
    c.execute("""CREATE TABLE word_basic(word, meaning, level)""")
except sqlite3.OperationalError:
    pass
finally:
    check_table()
c.fetchall()
check_word()
root.mainloop()
