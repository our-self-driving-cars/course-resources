import threading
import random

total = []
my_Lock = threading.Lock()

class Mythread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        global total
        for i in range(0, 50):
            pro_num = random.randint(0, 100)
            my_Lock.acquire()
            total.append(pro_num)
            my_Lock.release()

A = Mythread()
B = Mythread()
A.start()
B.start()
A.join()
B.join()

print(sum(total))