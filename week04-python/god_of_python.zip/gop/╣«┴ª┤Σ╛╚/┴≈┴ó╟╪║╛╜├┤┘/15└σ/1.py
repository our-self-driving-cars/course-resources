import threading
import time

class Mythread(threading.Thread):
    def __init__(self, sec, letter):
        threading.Thread.__init__(self)
        self.sec = sec
        self.letter = letter

    def run(self):
        while True:
            time.sleep(self.sec)
            print(self.letter)

thrA = Mythread(1, 'A')
thrB = Mythread(1.5, 'B')
thrC = Mythread(2, 'C')

thrA.start()
thrB.start()
thrC.start()