#함수를 사용하는 방법
import threading
import time

def func(sec, letter):
    while True:
        time.sleep(sec)
        print(letter)

thrA = threading.Thread(target = func, args = ((1, 'A')))
thrB = threading.Thread(target = func, args = ((1.5, 'B')))
thrC = threading.Thread(target = func, args = ((2, 'C')))

thrA.start()
thrB.start()
thrC.start()

"""
#callable 객체를 사용하는 방법
import threading
import time

class Mythread():
    def __init__(self, sec, letter):
        self.sec = sec
        self.letter = letter

    def __call__(self):
        while True:
            time.sleep(self.sec)
            print(self.letter)

A = Mythread(1, 'A')
B = Mythread(1.5, 'B')
C = Mythread(2, 'C')

thrA = threading.Thread(target =A)
thrB = threading.Thread(target =B)
thrC = threading.Thread(target =C)

thrA.start()
thrB.start()
thrC.start()
"""