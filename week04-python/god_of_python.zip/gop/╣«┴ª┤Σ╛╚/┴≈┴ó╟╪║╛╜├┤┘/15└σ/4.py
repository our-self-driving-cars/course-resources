import threading
import random

total_list = []

my_Lock = threading.Lock()


class Mythread(threading.Thread):
    def __init__(self, max, count):
        threading.Thread.__init__(self)
        self.count = count
        self.max = max

    def run(self):
        global total_list
        total = 0
        for i in range(0, self.count):
            pro_num = random.randint(1, self.max)
            total += pro_num
        my_Lock.acquire()
        total_list.append(total)
        my_Lock.release()

A = Mythread(100, 20)
B = Mythread(100, 30)

A.start()
B.start()

A.join()
B.join()

print(sum(total_list))