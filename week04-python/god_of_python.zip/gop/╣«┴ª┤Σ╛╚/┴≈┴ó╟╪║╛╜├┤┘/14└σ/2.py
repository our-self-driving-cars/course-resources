import tkinter
import random


class App():

    def __init__(self, master):
        self.master = master
        self.master.minsize(150, 50)
        self.master.maxsize(150, 50)

        self.value = tkinter.StringVar()

        self.frame = tkinter.Frame(master, width=150, height=50)
        self.frame.pack()

        self.label = tkinter.Label(self.frame, textvariable=self.value)
        self.label.grid(row=0, column=0)
        self.bt = tkinter.Button(self.frame, text="난수 생성", command=self.create)
        self.bt.grid(row=1, column=0)

    def start(self):
        self.master.mainloop()

    def create(self):
        k = random.sample(range(1, 46), 5)
        k.sort()
        self.value.set(k)

root = tkinter.Tk()
myApp = App(root)
myApp.start()
