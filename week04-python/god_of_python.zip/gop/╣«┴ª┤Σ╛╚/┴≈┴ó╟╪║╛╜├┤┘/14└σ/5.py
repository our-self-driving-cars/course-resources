import tkinter
from PIL import Image, ImageTk


class App():

    def __init__(self, master):
        master.geometry("1200x400")

        self.entry1_String = tkinter.StringVar(master)
        self.entry2_String = tkinter.StringVar(master)

        self.frame1 = tkinter.Frame(master, width=300, height=300, bg='yellow')
        self.frame2 = tkinter.Frame(master, width=300, height=300)
        self.frame3 = tkinter.Frame(master, width=300, height=300)
        self.cvs1 = tkinter.Canvas(self.frame1, bg="yellow", width=300, height=300)
        self.cvs2 = tkinter.Canvas(self.frame2)
        self.cvs3 = tkinter.Canvas(self.frame3)
        self.frame4 = tkinter.Frame(master, width=600, height=100)
        self.entry1 = tkinter.Entry(self.frame4, width=70, textvariable=self.entry1_String)
        self.entry2 = tkinter.Entry(self.frame4, width=70, textvariable=self.entry2_String)
        self.button = tkinter.Button(self.frame4, text="emerge", command=self.emerge)

        self.frame1.grid(row=0, column=0)
        self.frame2.grid(row=0, column=1)
        self.frame3.grid(row=0, column=2)
        self.cvs1.pack()
        self.cvs2.pack()
        self.cvs3.pack()
        self.frame4.grid(row=1, column=0, columnspan=3)
        self.entry1.grid(row=0, column=0)
        self.entry2.grid(row=1, column=0)
        self.button.grid(row=0, rowspan=2, column=1)
        self.PILimg1 = None
        self.PILimg2 = None
        self.CVSimg1 = None
        self.CVSimg2 = None
        self.CVSimg3 = None


#여기서는 세세한 조정은 하지 않고 첫 번째 이미지에 두 번째 이미지를 붙여 넣기만 할 것이다.
    def emerge(self):
        self.PILimg1 = Image.open(self.entry1_String.get())
        self.CVSimg1 = ImageTk.PhotoImage(self.PILimg1)
        self.cvs1.create_image((150, 150), image=self.CVSimg1)

        self.PILimg2 = Image.open(self.entry2_String.get())
        self.CVSimg2 = ImageTk.PhotoImage(self.PILimg2)
        self.cvs2.create_image((150, 150), image=self.CVSimg2)

        self.PILimg1.paste(self.PILimg2, (self.PILimg1.size[0]//2, self.PILimg1.size[1]//2))
        self.CVSimg3 = ImageTk.PhotoImage(self.PILimg1)

        self.cvs3.create_image((150, 150), image=self.CVSimg3)

root = tkinter.Tk()
myApp = App(root)
root.mainloop()
