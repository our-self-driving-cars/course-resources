import tkinter


class App():

    def __init__(self, master):
        self.master = master
        self.cvs = tkinter.Canvas(self.master, width=200, height=150)
        self.cvs.pack()

        self.pakc_man = self.cvs.create_arc(
            (30, 30, 50, 50), start=45, extent=270)

        self.bt_left = tkinter.Button(text="left", command=self.left)
        self.bt_right = tkinter.Button(text="right", command=self.right)
        self.bt_up = tkinter.Button(text="up", command=self.up)
        self.bt_down = tkinter.Button(text="down", command=self.down)
        self.cvs.create_window(130, 100, window=self.bt_left)
        self.cvs.create_window(170, 100, window=self.bt_right)
        self.cvs.create_window(150, 80, window=self.bt_up)
        self.cvs.create_window(150, 120, window=self.bt_down)

    def left(self):
        self.cvs.move(self.pakc_man, -10, 0)

    def right(self):
        self.cvs.move(self.pakc_man, 10, 0)

    def up(self):
        self.cvs.move(self.pakc_man, 0, -10)

    def down(self):
        self.cvs.move(self.pakc_man, 0, 10)

root = tkinter.Tk()
myApp = App(root)
root.mainloop()
