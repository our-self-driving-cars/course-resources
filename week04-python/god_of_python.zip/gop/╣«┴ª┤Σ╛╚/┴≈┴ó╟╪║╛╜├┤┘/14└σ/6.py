import tkinter


class App():

    def __init__(self, master):
        self.frame = tkinter.Frame(master, width=500, height=500)
        self.cvs = tkinter.Canvas(self.frame, bg="yellow")
        self.frame.pack()
        self.cvs.pack()

        self.cvs.bind("<Button-1>", self.first_click)
        self.cvs.bind("<B1-Motion>", self.draw)      # 마우스 왼쪽 클릭, 마우스 이동이 동시에

        self.old_x = None
        self.old_y = None

    def first_click(self, e):
        self.old_x = e.x
        self.old_y = e.y

    def draw(self, e):
        self.cvs.create_line((self.old_x, self.old_y, e.x, e.y))
        self.old_x = e.x
        self.old_y = e.y


root = tkinter.Tk()
root.title("Motion")
myApp = App(root)
root.mainloop()
