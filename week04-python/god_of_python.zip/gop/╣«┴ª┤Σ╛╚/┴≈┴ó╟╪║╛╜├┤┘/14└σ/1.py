import tkinter


class App():

    def __init__(self, master):
        self.master = master
        self.master.minsize(200, 50)

        self.frame = tkinter.Frame(master, width=100, height=50)
        self.frame.pack()

        self.x = tkinter.IntVar(self.master, 100)
        self.y = tkinter.IntVar(self.master, 100)

        self.win_width = tkinter.Entry(self.frame, textvariable=self.x)
        self.win_height = tkinter.Entry(self.frame, textvariable=self.y)
        self.win_width.grid(row=0, column=0)
        self.win_height.grid(row=0, column=1)

        self.bt = tkinter.Button(self.frame, text="계산", command=self.calc)
        self.bt.grid(row=1, column=0, columnspan=2)

    def calc(self):
        self.master.geometry(str(self.x.get()) + 'x' + str(self.y.get()))

root = tkinter.Tk()
myapp = App(root)
root.mainloop()
