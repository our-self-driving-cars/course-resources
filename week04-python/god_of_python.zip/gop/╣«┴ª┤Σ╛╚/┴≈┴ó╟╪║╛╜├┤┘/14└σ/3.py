import tkinter


class App():

    def __init__(self, master):
        self.master = master
        self.master.title("login")
        self.master.geometry("200x100")
        self.text_id = tkinter.StringVar(value='')
        self.text_pw = tkinter.StringVar(value='')

        self.frame = tkinter.Frame(self.master)
        self.frame.pack()

        self.label_id = tkinter.Label(self.frame, text="id")
        self.label_pw = tkinter.Label(self.frame, text="pw")
        self.label_id.grid(row=0, column=0)
        self.label_pw.grid(row=1, column=0)
        self.label_login = tkinter.Label(self.frame, text="로그인 성공")

        self.entry_id = tkinter.Entry(self.frame, textvariable=self.text_id)
        self.entry_pw = tkinter.Entry(
            self.frame, textvariable=self.text_pw, show='*')
        self.entry_id.grid(row=0, column=1)
        self.entry_pw.grid(row=1, column=1)

        self.bt = tkinter.Button(
            self.frame, text="login", command=self.try_log_in)
        self.bt.grid(row=2, column=1)

    def try_log_in(self):
        id = self.text_id.get()
        pw = self.text_pw.get()
        with open("idpw.txt", "rt") as f:
            for line in f:
                idpw_list = line.strip().split("/")
                if id == idpw_list[0] and pw == idpw_list[1]:
                    print("correct")
                    break
                else:
                    pass
            else:
                print("login failed")
                return 0

        self.entry_id.destroy()
        self.entry_pw.destroy()
        self.label_id.destroy()
        self.label_pw.destroy()
        self.bt.destroy()

        self.label_login.grid(row=0, column=0)
        return 0

root = tkinter.Tk()
myApp = App(root)
root.mainloop()
