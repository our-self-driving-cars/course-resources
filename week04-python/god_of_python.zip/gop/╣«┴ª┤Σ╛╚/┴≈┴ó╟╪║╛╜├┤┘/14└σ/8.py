
import tkinter
import os
from tkinter import filedialog


class App():
    def __init__(self, master):
        self.menubar = tkinter.Menu(master)
        master['menu'] = self.menubar
        self.menu_file = tkinter.Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(menu=self.menu_file, label="File")
        self.menu_file.add_command(label="open", command=self.openfile)
        self.menu_file.add_command(label="save", command=self.savefile)
        self.menu_file.add_command(label="save as", command=self.saveasfile)
        self.text = tkinter.Text(master, width=40, height=10)
        self.text.pack()

        self.file_path = None
        self.f = None


# 주의 : openfile 메소드로 열게 되는 파일의 encoding은 'utf-8'로 할 것
    def openfile(self):
        self.file_path = filedialog.askopenfilename()   #파일 경로 + 파일 이름 + 파일 확장명
        self.f = open(self.file_path, "r", encoding='utf-8')
        self.text.delete("1.0", "end")
        self.text.insert("1.0", self.f.read())
        self.f.close()

    def savefile(self):
        if not self.file_path:      #file_path가 None이면(즉, 아직 열어놓거나 저장된 파일이 없다면)
            self.file_path = filedialog.asksaveasfilename()     # 새롭게 파일 위치 지정(file_path에)
        self.f = open(self.file_path, mode='w', encoding='utf-8')   #file_path의 파일을 쓰기모드로 연다.
        self.f.seek(0, 0)
                                                        #참고 : get메소드로 얻어진 문자열에 "\n"가 추가된다.
        self.f.write(self.text.get("1.0", "end-1c"))    #-1c는 뒤에서 -1만큼의 원고지(텍스트)를 가리키는 칸을 이동(-2c는 -2만큼, 3c는 3만큼...)
                                                        #-1l은 한 줄 앞을 가리킨다., 2l은 2줄 뒤를 가리킨다.
        self.f.flush()
        self.f.close()

    def saveasfile(self):
        self.file_path = filedialog.asksaveasfilename()     # 새롭게 파일 위치 지정(file_path에)
        self.f = open(self.file_path, mode='w', encoding='utf-8')   #file_path의 파일을 쓰기모드로 연다.
        self.f.seek(0, 0)
        self.f.write(self.text.get("1.0", "end-1c"))
        self.f.flush()
        self.f.close()

root = tkinter.Tk()
myApp = App(root)
root.mainloop()
