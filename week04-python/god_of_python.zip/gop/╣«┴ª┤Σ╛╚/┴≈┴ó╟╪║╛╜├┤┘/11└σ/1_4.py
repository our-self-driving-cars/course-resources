from Student import Student

class MyStudent(Student):
    schoolname = "Python_School"    #학교 이름 클래스 속성
    principle = "someone"		    #교장 이름 클래스 속성
    @classmethod
    def change_schoolname(cls, sc_name):
        cls.schoolname = sc_name
    @classmethod
    def change_principle(cls, p_name):	#교장 이름 변경 클래스 메소드
        cls.principle = p_name
    def __init__(self, name, grade, s_class, number, score, etc, address):
        Student.__init__(self, name, grade, s_class, number, score, etc)
        self.address = address
    def up_grade(self):
        new_grade = self.grade+1
        if new_grade > 3:
            self.grade = "graduation"
            print("graduation")
        else:
            self.grade = new_grade
            self.s_class = "반을 정해주세요"
    def down_grade(self):
        new_grade = self.grade-1
        if new_grade == 0:
            print("can't down grade")
        else:
            self.grade = new_grade
            self.s_class = "반을 정해주세요"
    def show_info(self):
        print("학교이름 : {},\n\
교장 : {}\n\
학생 정보\n\
이름 : {}\n\
학년 : {}\n\
반   : {}\n\
번호 : {}\n\
성적 : {}\n\
주소 : {}".format(MyStudent.schoolname, MyStudent.principle, \
self.name, self.grade, self.s_class, self.number, self.score, self.address))


if __name__ == "__main__":
    stdobj = MyStudent("철수", 3, 10, 31, 99, None, "Seoul jongrogu ...")
    stdobj.show_info()