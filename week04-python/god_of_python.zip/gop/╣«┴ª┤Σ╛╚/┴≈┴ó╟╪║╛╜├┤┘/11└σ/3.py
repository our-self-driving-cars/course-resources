class Elf():
    def __init__(self, name, item):
        self.__name = name
        self.__item = item
    def choose_item(self, item):
        print("{} Elf choose {}".format(self.__name, item.name))
        self.__item = item
    def use_item(self):
        try:
            self.__item.use()
        except AttributeError:
            print("사용할 아이템이 없음!") 


class Car():
    def __init__(self, name, model):
        self.__name = name+" Car"
        self.__model = model
    def use(self):
        print("use {} **model : {}**".format(self.__name, self.__model))
    @property
    def name(self):
        return self.__name

if __name__ == "__main__":
    elf_A = Elf("elf_A", None)
    elf_A.use_item()
    car_A = Car("Super Car", "T-1000")
    elf_A.choose_item(car_A)
    elf_A.use_item()
