class Student():
    def __init__(self, name, grade, s_class, number, score, etc):
        #이름, 학년, 반, 번호, 성적, 기타
        self.name = name
        self.grade = grade
        self.s_class = s_class
        self.number = number
        self.score=score
    def up_grade(self): #한 학년 높임. 단, 3학년을 초과하면 grade는 'graduation'
            pass
    def down_grade(self):  #한 학년 낮춤
        pass
    def show_info(self):   #학생정보출력(출력 형식은 학교, 학년, 반..., 기타 순서로)
        pass
