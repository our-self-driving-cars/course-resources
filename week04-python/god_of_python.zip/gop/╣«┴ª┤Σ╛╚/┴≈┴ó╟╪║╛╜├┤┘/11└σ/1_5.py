class Student():
    def __init__(self, name, grade, s_class, number, score, etc):
    #이름, 학년, 반, 번호, 성적, 기타
        #self.name = name		#주석처리
        self.grade = grade
        self.s_class = s_class
        self.number = number
        self.score=score
        self.etc = etc
    def up_grade(self): 
        pass
    def down_grade(self):
        pass
    def show_info(self): 
        pass


class MyStudent(Student):
    principle = "someone"
    @classmethod
    def change_principle(cls, p_name):
        cls.principle = p_name
    def __init__(self, name, grade, s_class, number, score, etc, address):
        Student.__init__(self, name, grade, s_class, number, score, etc)
        self.__name = name		#private 접근 지정
        self.address = address
    def up_grade(self):
        new_grade=self.grade+1
        if new_grade > 3:
            self.grade = "graduation"
            print("graduation")
        else:
            self.grade = new_grade
            self.s_class = "반을 정해주세요"
    def down_grade(self):
        new_grade = self.grade-1
        if new_grade == 0:
            print("can't down grade")
        else:
            self.grade = new_grade
            self.s_class = "반을 정해주세요"
    def show_info(self):
        print("학생 정보")
        print("""이름 : {}
학년 : {},
반   : {},
번호 : {},
성적 : {},
주소 : {}""".format(self.name, self.grade, self.s_class, self.number, self.score, self.address))
    @property			#name property
    def name(self):
        return self.__name

if __name__ == "__main__":
    stdobj = MyStudent("철수", 3, 10, 31, 99, None, "Seoul jongrogu ...")
    stdobj.show_info()
    print("name property :", stdobj.name)       #이름 property 출력
