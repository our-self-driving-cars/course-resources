class myclass(list):
    def __sub__(self, obj):
        if isinstance(obj, list):
            return list(set(self)-set(obj))

if __name__ == "__main__":
    list_obj_A = myclass([1,3,4,5,6,7,8])
    list_obj_B = myclass([1,4,6,7])
    print("list_obj_A : ", list_obj_A)
    print("list_obj_B : ", list_obj_B)
    print("list_obj_A - list_obj_B", list_obj_A - list_obj_B)