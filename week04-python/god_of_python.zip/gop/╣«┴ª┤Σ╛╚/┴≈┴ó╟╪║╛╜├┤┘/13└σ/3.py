import time

try:
    a =0
    while(True):
        print(a)
        time.sleep(1)
        a += 1
        if a == 11:
            break
except KeyboardInterrupt:
    print("exit")

else:
    print("complete")

finally:
    print("Goodbyt Python")