class MyExcept(Exception):
    def __init__(self, string):
        self.string = string
    def __str__(self):
        return "\"{}\" has p.".format(self.string)

if __name__ == "__main__":
    while True:
        data = input()
        try:
            for s in data:
                if s == 'p':
                    raise MyExcept(data)
            else:
                print("\"{}\" has no p.".format(data))
        except MyExcept as e:
            print(e)
