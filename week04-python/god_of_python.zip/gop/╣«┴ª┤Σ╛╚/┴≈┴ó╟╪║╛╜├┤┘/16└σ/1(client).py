# multichat_Client.py
from socket import *
import threading
import tkinter
import time

class GUI_part():
    def __init__(self, master):
        # GUI_START
        self.master = master
        self.master.protocol("WM_DELETE_WINDOW", func=self.delete_window)
        self.master.title("Python_Multichat_Client")
        self.chat_string = tkinter.StringVar()
        self.port_number = tkinter.IntVar()
        self.port_number.set(62580)
        self.frame = tkinter.Frame(master)
        self.frame.pack()

        self.main_text = tkinter.Text(self.frame, width=70, height=40, background='green', foreground='white', yscrollcommand=True)
        self.main_text.grid(row=0, rowspan=5, column=0)
        self.chat_entry = tkinter.Entry(self.frame, width=60, textvariable=self.chat_string)
        self.chat_entry.grid(row=5, column=0, sticky='w')
        
        self.conlist_label = tkinter.Label(self.frame, text="Connection List")
        self.conlist_label.grid(row=0, column=1, columnspan=2)
        self.con_list = tkinter.Text(self.frame, width=25, height=30, background='green', foreground='white')
        self.con_list.grid(row=1, column=1, columnspan=2, sticky='n')
        
        self.servip_label = tkinter.Label(self.frame, text="Server IP")
        self.servip_label.grid(row=2, column=1, sticky='n')
        self.servip_entry = tkinter.Entry(self.frame, width=15)
        self.servip_entry.grid(row=2, column=2, sticky='n')

        self.servport_label = tkinter.Label(self.frame, text="Server Port")
        self.servport_label.grid(row=3, column=1, sticky='n')
        self.servport_entry = tkinter.Entry(self.frame, width=15, textvariable=self.port_number)
        self.servport_entry.grid(row=3, column=2, sticky='n')

        self.con_button = tkinter.Button(self.frame, text="Connect...", command=self.connection)
        self.con_button.grid(row=4, column=1)

        self.discon_button = tkinter.Button(self.frame, text="Disconnect...", command=self.disconnection)
        self.discon_button.grid(row=4, column=2)

        self.status_label = tkinter.Label(self.frame, text="status : offline")
        self.status_label.grid(row=5, column=1)
        
        #GUI_END
        self.mysock = None


    def delete_window(self):
        try:
            self.mysock.shutdown(SHUT_RD)
            self.mysock.shutdown(SHUT_WR)
            self.mysock.close()
        except (AttributeError, OSError):
            pass
        self.master.destroy()


    def connection(self):
        self.servip = self.servip_entry.get()     #'127.0.0.1'  # 또는 서버의 IP주소
        self.servport = self.port_number.get()
        self.address = (self.servip, self.servport)
        try:
            self.mysock.getpeername()
        except (OSError, AttributeError):
            self.mysock = socket(AF_INET, SOCK_STREAM)
            self.main_text.insert("end", "connecting to server {} on port {}...\n".format(self.servip, self.servport))
            try:
                self.mysock.connect(self.address)
            except OSError as e:
                self.main_text.insert("end", e)
                self.main_text.insert("end", "\n")
                self.main_text.see("end")
            else:
                self.main_text.insert("end", "connection complete\n")
                self.main_text.insert("end", "If you want to leave chat, just type !quit\n\n")
                self.main_text.see("end")
                self.status_label.config(text="status : online")
                recvthread = threading.Thread(target=self.receive_thread)
                recvthread.start()

        else:
            self.main_text.insert("end", "현재 {}에 연결된 상태입니다.\n".format(self.mysock.getpeername()[0]))
            self.main_text.see("end")
            return 0


    def disconnection(self):
        try:
            self.mysock.getpeername()
        except (OSError, AttributeError):
            self.main_text.insert("end", "현재 연결된 서버가 없습니다.\n")
            self.main_text.see("end")
            return 0
        self.chat_entry.focus()
        self.chat_string.set("!quit")
        self.chat_entry.event_generate("<Return>", when="now")
        return 0

    def receive_thread(self):
        while True:
            try:
                self.recv_data = self.mysock.recv(1024)
            except ConnectionError:  # 서버 강제 종료
                try:
                    self.main_text.insert("end", "서버와의 접속이 끊겼습니다.\n")
                except RuntimeError:
                    pass
                break
            except OSError:
                raise SystemExit

            if not self.recv_data:  # 서버 정상 종료
                try:
                    self.main_text.insert("end", "서버로부터 정상적으로 로그아웃 했습니다.\n")
                except RuntimeError:
                    pass
                break

            #전송 받은 데이터가 클라이언트 접속 목록인지 헤더검사.
            if self.recv_data.startswith(bytes([1,2,3,4,5,6,7,8,9])):   
                self.clients_list = eval(self.recv_data[9:])
                self.con_list.delete("1.0", 'end')
                for l in self.clients_list:
                    self.con_list.insert("end", str(l)+'\n')
                continue
            
            try:
                self.main_text.insert("end", self.recv_data.decode("UTF-8")+"\n")
                self.main_text.see("end")
            except RuntimeError:
                pass
        
        self.status_label.config(text="status : offline")

        try:
            self.main_text.insert("end", "소켓의 읽기버퍼를 닫습니다.\n")
        except RuntimeError:
            pass
        self.mysock.shutdown(SHUT_RD)
        self.mysock.close()
        self.main_text.insert("end", "소켓을 닫습니다.\n")
        self.main_text.see("end")
        return 0

root = tkinter.Tk()
myGui = GUI_part(root)


#채팅 데이터 전송(send)을 위한 class
class send_entry():
    def __init__(self, gui_obj):
        self.gui_obj = gui_obj

    def send_message(self, e):
        try:
            self.send_data = self.gui_obj.chat_entry.get()
            self.gui_obj.chat_entry.delete(0, 60)
            #self.gui_obj.main_text.insert("end", self.send_data + '\n')
            #self.send_data = input("")  # 전송할 데이터 입력
        except KeyboardInterrupt:
            pass

        if self.send_data == '!quit':  # 접속 종료 시도
            try:
                self.gui_obj.main_text.insert("end", "서버와의 접속을 끊는 중 입니다.(!quit)\n")
            except RuntimeError:
                pass
            finally:
                self.gui_obj.mysock.shutdown(SHUT_WR)
                return 0

        try:
            self.gui_obj.mysock.send(bytes(self.send_data, "UTF-8"))  # 데이터 전송
            return 0
        except ConnectionError:
            self.gui_obj.mysock.shutdown(SHUT_WR)
        except (OSError, AttributeError):
            return 0

        try:
            self.gui_obj.main_text.insert("end", "소켓의 쓰기버퍼를 닫습니다.\n")
        except RuntimeError:
            pass



myMessage = send_entry(myGui)

#채팅 데이터 수신(receive)을 위한 thread class



myGui.chat_entry.bind("<Return>", myMessage.send_message)   # 채팅 메세지 입력 후 Enter에 대한 event


root.resizable(False, False)
root.mainloop()